# CSS Refactor TODO

## Plan
- [ ] Centralize all inline/internal `<style>` CSS into `styles.css`.
- [ ] Ensure every page links to `styles.css` using `<link rel="stylesheet" href="styles.css">`.
- [ ] Refactor `index.php`, `login.php`, `register.php`, `admin.php`, `dashboard.php`, `approve.php`, `items.php`, and `DBConn.php` markup to use shared classes.
- [ ] Remove duplicate/unused CSS classes after migration.
- [ ] Improve responsiveness using existing `styles.css` grid/flex + media queries.
- [ ] Verify pages render without missing class names.

## Progress
- [x] Created `styles.css`.
- [x] Updated `index.php` to link to `styles.css` and removed top-level `<style>`.
- [x] Finish updating remaining PHP/HTML pages to link to `styles.css` and remove inline styles.


