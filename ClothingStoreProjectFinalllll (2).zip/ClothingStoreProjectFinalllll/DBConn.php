<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "ClothingStore";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Database Error</title>

        <style>

            *{
                margin:0;
                padding:0;
                box-sizing:border-box;
                font-family:Arial, sans-serif;
            }

            body{
                height:100vh;
                display:flex;
                justify-content:center;
                align-items:center;
                background:#f4f4f4;
            }

            .error-box{
                width:420px;
                background:white;
                padding:40px;
                border-radius:12px;
                text-align:center;
                box-shadow:0 8px 20px rgba(0,0,0,0.15);
            }

            .error-box h1{
                color:#111;
                margin-bottom:20px;
                font-size:32px;
            }

            .error-box p{
                color:red;
                font-size:16px;
                margin-bottom:25px;
            }

            .btn{
                display:inline-block;
                padding:12px 25px;
                background:black;
                color:white;
                text-decoration:none;
                border-radius:6px;
                transition:0.3s;
            }

            .btn:hover{
                background:#333;
            }

        </style>
    </head>

    <body>

    <div class="error-box">

        <h1>Fashion Store</h1>

        <p>
            <?php echo "Connection failed: " . $conn->connect_error; ?>
        </p>

        <a href="index.php" class="btn">Back to Home</a>

    </div>

    </body>
    </html>
<?php
exit();
}
?>