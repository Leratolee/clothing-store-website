<?php
include 'DBConn.php';

$message = "";

// Drop old table
$conn->query("DROP TABLE IF EXISTS tblUser");

// Create fresh table
$createTable = "
CREATE TABLE tblUser(
    userID INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    username VARCHAR(50),
    password VARCHAR(255),
    status VARCHAR(20)
)";

if($conn->query($createTable)){

    $file = fopen("userData.txt", "r");

    if($file){

        // Prepared statement
        $stmt = $conn->prepare("
            INSERT INTO tblUser(name,email,username,password,status)
            VALUES(?,?,?,?,?)
        ");

        while(($line = fgetcsv($file)) !== FALSE){

            $name = trim($line[0]);
            $email = trim($line[1]);
            $username = trim($line[2]);

            // Secure password hashing
            $password = password_hash(trim($line[3]), PASSWORD_DEFAULT);

            $status = "approved";

            $stmt->bind_param(
                "sssss",
                $name,
                $email,
                $username,
                $password,
                $status
            );

            $stmt->execute();
        }

        fclose($file);

        $message = "Customer data imported successfully!";
    }
    else{
        $message = "Unable to open userData.txt";
    }

}
else{
    $message = "Failed to create table!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Fashion Store Import</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Poppins', sans-serif;
        }

        body{
            background:#f5f5f5;
            height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
        }

        .container{
            width:450px;
            background:white;
            padding:40px;
            border-radius:15px;
            text-align:center;
            box-shadow:0 10px 25px rgba(0,0,0,0.1);
        }

        h1{
            margin-bottom:20px;
            color:#111;
            font-size:30px;
        }

        p{
            font-size:17px;
            margin-bottom:25px;
            color:#555;
        }

        .success{
            color:green;
            font-weight:bold;
        }

        .error{
            color:red;
            font-weight:bold;
        }

        .btn{
            display:inline-block;
            padding:12px 28px;
            background:black;
            color:white;
            text-decoration:none;
            border-radius:8px;
            transition:0.3s;
        }

        .btn:hover{
            background:#333;
        }

    </style>
</head>

<body>

<div class="container">

    <h1>Fashion Store</h1>

    <p class="<?php echo (strpos($message, 'successfully') !== false) ? 'success' : 'error'; ?>">
        <?php echo $message; ?>
    </p>

    <a href="dashboard.php" class="btn">Go to Dashboard</a>

</div>

</body>
</html>