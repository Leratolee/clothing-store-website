<?php
include 'DBConn.php';


if(isset($_GET['delete']))
{
    $id = $_GET['delete'];
    $conn->query("DELETE FROM tblClothes WHERE itemID='$id'");
    header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Administrator Dashboard</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="styles.css">

<style>

body{
    background:#f5f5f5;
    padding:40px;
    font-family:Arial;
}

.container{
    width:90%;
    margin:auto;
    background:white;
    padding:30px;
    border-radius:10px;
}

h2{
    text-align:center;
}

.addBtn{
    background:black;
    color:white;
    padding:10px 20px;
    text-decoration:none;
    border-radius:5px;
}

table{
    width:100%;
    margin-top:20px;
    border-collapse:collapse;
}

table th,table td{
    border:1px solid #ddd;
    padding:12px;
    text-align:center;
}

.edit{
    background:green;
    color:white;
    padding:8px 12px;
    text-decoration:none;
    border-radius:5px;
}

.delete{
    background:red;
    color:white;
    padding:8px 12px;
    text-decoration:none;
    border-radius:5px;
}

</style>

</head>

<body>

<div class="container">

<h2>Administrator Dashboard</h2>

<a href="addItem.php" class="addBtn">Add Clothing Item</a>

<table>

<tr>

<th>ID</th>
<th>Item Name</th>
<th>Price</th>
<th>Brand</th>
<th>Actions</th>

</tr>

<?php

$result = $conn->query("SELECT * FROM tblClothes");

while($row = $result->fetch_assoc())
{

?>

<tr>

<td><?php echo $row['itemID']; ?></td>

<td><?php echo $row['itemName']; ?></td>

<td>R <?php echo $row['price']; ?></td>

<td><?php echo $row['brand']; ?></td>

<td>

<a class="edit" href="editItem.php?id=<?php echo $row['itemID']; ?>">
Update
</a>

<a class="delete" href="dashboard.php?delete=<?php echo $row['itemID']; ?>" onclick="return confirm('Delete this item?')">
Delete
</a>

</td>

</tr>

<?php
}
?>

</table>

</div>

</body>

</html>