<?php include 'DBConn.php'; ?>

<?php
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $conn->query("INSERT INTO tblUser (name,email,username,password,status)
    VALUES ('$name','$email','$username','$password','pending')");

    $message = "Registered successfully! Wait for admin approval.";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="styles.css">


.box{
    background:white;
    padding:30px;
    border-radius:10px;
    width:320px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
    text-align:center;
}

h2{
    margin-bottom:15px;
}

input{
    width:100%;
    padding:10px;
    margin:8px 0;
    border:1px solid #ddd;
    border-radius:5px;
}

button{
    width:100%;
    padding:10px;
    background:black;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
}

button:hover{
    background:#444;
}

.msg{
    margin-top:10px;
    color:green;
    font-size:14px;
}

a{
    display:block;
    margin-top:10px;
    color:black;
    text-decoration:none;
}

</head>

<body>

<div class="center">

  <div class="card form-card">

  <h2 style="margin-bottom:16px; text-align:center;">Register</h2>

  <form method="POST">


    <input type="text" name="name" placeholder="Full Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>

    <button type="submit">Register</button>

</form>

<div class="message success" role="status">
    <?php echo $message; ?>
</div>

<a class="btn secondary" href="login.php">Already have an account? Login</a>

  </div>

</body>
</html>