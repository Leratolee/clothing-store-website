<?php
include 'DBConn.php';
session_start();


if(isset($_POST['addCart']))
{
    $itemID = $_POST['itemID'];

    if(!isset($_SESSION['cart']))
    {
        $_SESSION['cart'] = array();
    }

    
    if(isset($_SESSION['cart'][$itemID]))
    {
        $_SESSION['cart'][$itemID]++;
    }
    else
    {
        $_SESSION['cart'][$itemID] = 1;
    }

    echo "<script>alert('Item added to cart successfully!');</script>";
}
?>

<!DOCTYPE html>
<html>

<head>

    <title>Items - Pastimes Clothing Store</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="styles.css">

</head>

<body>

<main class="container">

<h2 class="section-title">Our Latest Fashion Items</h2>

<div class="grid items-grid">

<?php

$res = $conn->query("SELECT * FROM tblClothes");

while($row = $res->fetch_assoc())
{

?>

<div class="item-card">

    <img src="images/sample.jpg" alt="Clothing Item">

    <div class="name">
        <?php echo $row['itemName']; ?>
    </div>

    <div class="price">
        R <?php echo $row['price']; ?>
    </div>

    <form method="POST">

        <input type="hidden" name="itemID" value="<?php echo $row['itemID']; ?>">

        <button class="btn" type="submit" name="addCart">
            Add to Cart
        </button>

    </form>

</div>

<?php

}

?>

</div>

<br>

<a href="cart.php">
    <button class="btn">View Shopping Cart</button>
</a>

</main>

</body>

</html>