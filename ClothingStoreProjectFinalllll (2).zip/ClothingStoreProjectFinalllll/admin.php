<?php
include 'DBConn.php';
session_start();

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM tblAdmin WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {

        $admin = $result->fetch_assoc();

    
        if (password_verify($password, $admin['password'])) {

            session_regenerate_id(true);

            $_SESSION['admin'] = $admin['email'];

            header("Location: dashboard.php");
            exit();

        } else {
            $message = "Invalid password!";
        }

    } else {
        $message = "Admin not found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>

    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="styles.css">

        
</head>

<body>

<div class="center">

    <div class="card form-card">


    <h2>Admin Login</h2>

    <?php if($message != "") { ?>
        <div class="message error"><?php echo $message; ?></div>

    <?php } ?>

    <form method="POST">

        <div class="input-group">
            <label>Email</label>
            <input type="email" name="email" required>
        </div>

        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>

        <button type="submit" class="btn">Login</button>

    </form>


</div>

</body>
</html>