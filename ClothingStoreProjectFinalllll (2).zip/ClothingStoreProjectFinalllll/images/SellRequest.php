<?php
include 'DBConn.php';

$message = "";

if(isset($_POST['submit']))
{
    $itemName = $_POST['itemName'];
    $brand = $_POST['brand'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    
    $image = $_FILES['image']['name'];
    $temp = $_FILES['image']['tmp_name'];

    $folder = "images/" . $image;

    move_uploaded_file($temp, $folder);

    $status = "Pending";

    $sql = "INSERT INTO tblSellerRequest
    (itemName,brand,description,price,image,status)
    VALUES
    ('$itemName','$brand','$description','$price','$image','$status')";

    if($conn->query($sql))
    {
        $message = "Request submitted successfully. Waiting for administrator approval.";
    }
    else
    {
        $message = "Error submitting request.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Sell Clothing Request</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="styles.css">

<style>

body{
    background:#f5f5f5;
    font-family:Arial;
}

.container{
    width:600px;
    margin:40px auto;
    background:white;
    padding:30px;
    border-radius:10px;
}

h2{
    text-align:center;
}

input,textarea{
    width:100%;
    padding:12px;
    margin:10px 0;
}

button{
    width:100%;
    padding:12px;
    background:black;
    color:white;
    border:none;
    cursor:pointer;
}

.success{
    color:green;
    text-align:center;
    margin-bottom:15px;
}

</style>

</head>

<body>

<div class="container">

<h2>Sell Clothing Request</h2>

<?php
if($message != "")
{
    echo "<p class='success'>$message</p>";
}
?>

<form method="POST" enctype="multipart/form-data">

<label>Clothing Name</label>

<input
type="text"
name="itemName"
required>

<label>Brand</label>

<input
type="text"
name="brand"
required>

<label>Description</label>

<textarea
name="description"
rows="5"
required></textarea>

<label>Price</label>

<input
type="number"
name="price"
step="0.01"
required>

<label>Upload Image</label>

<input
type="file"
name="image"
accept="image/*"
required>

<button
type="submit"
name="submit">
Submit Request
</button>

</form>

</div>

</body>

</html>