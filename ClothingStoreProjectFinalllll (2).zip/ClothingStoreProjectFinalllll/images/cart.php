<?php
include 'DBConn.php';
session_start();
?>

<!DOCTYPE html>
<html>

<head>

<title>Shopping Cart</title>

<link rel="stylesheet" href="styles.css">

</head>

<body>

<h2>Your Shopping Cart</h2>

<table class="cart-table">

<tr>

<th>Item</th>
<th>Price</th>
<th>Quantity</th>
<th>Total</th>

</tr>

<?php

$total = 0;

if(isset($_SESSION['cart']))
{

foreach($_SESSION['cart'] as $itemID => $quantity)
{

$result = $conn->query("SELECT * FROM tblClothes WHERE itemID='$itemID'");

$item = $result->fetch_assoc();

$subtotal = $item['price'] * $quantity;

$total += $subtotal;

?>

<tr>

<td><?php echo $item['itemName']; ?></td>

<td>R <?php echo $item['price']; ?></td>

<td><?php echo $quantity; ?></td>

<td>R <?php echo $subtotal; ?></td>

</tr>

<?php

}

}

?>

<tr>

<td colspan="3"><strong>Grand Total</strong></td>

<td><strong>R <?php echo $total; ?></strong></td>

</tr>

</table>

<br>

<a href="items.php">
<button class="btn">Continue Shopping</button>
</a>

<a href="checkout.php">
<button class="btn">Checkout</button>
</a>

</body>

</html>