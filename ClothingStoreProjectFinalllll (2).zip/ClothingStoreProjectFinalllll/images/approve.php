<?php
include 'DBConn.php';


if(isset($_GET['approve']))
{
    $id = $_GET['approve'];

    
    $result = $conn->query("SELECT * FROM tblSellerRequest WHERE requestID='$id'");
    $row = $result->fetch_assoc();

    
    $conn->query("INSERT INTO tblClothes(itemName,brand,description,price,image)
    VALUES(
    '".$row['itemName']."',
    '".$row['brand']."',
    '".$row['description']."',
    '".$row['price']."',
    '".$row['image']."'
    )");

    
    $conn->query("UPDATE tblSellerRequest
    SET status='Approved'
    WHERE requestID='$id'");

    header("Location: approve.php");
}


if(isset($_GET['delete']))
{
    $id = $_GET['delete'];

    $conn->query("DELETE FROM tblSellerRequest WHERE requestID='$id'");

    header("Location: approve.php");
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Approve Seller Requests</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="styles.css">

<style>

body{
    background:#f5f5f5;
    font-family:Arial;
}

.container{
    width:90%;
    margin:auto;
    background:white;
    padding:30px;
    margin-top:30px;
    border-radius:10px;
}

h2{
    text-align:center;
}

table{
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
}

table th,
table td{
    border:1px solid #ddd;
    padding:12px;
    text-align:center;
}

img{
    width:80px;
    height:80px;
    object-fit:cover;
}

.approveBtn{
    background:green;
    color:white;
    padding:8px 15px;
    text-decoration:none;
    border-radius:5px;
}

.deleteBtn{
    background:red;
    color:white;
    padding:8px 15px;
    text-decoration:none;
    border-radius:5px;
}

</style>

</head>

<body>

<div class="container">

<h2>Pending Seller Requests</h2>

<table>

<tr>

<th>ID</th>
<th>Image</th>
<th>Item Name</th>
<th>Brand</th>
<th>Description</th>
<th>Price</th>
<th>Status</th>
<th>Action</th>

</tr>

<?php

$result = $conn->query("SELECT * FROM tblSellerRequest WHERE status='Pending'");

while($row = $result->fetch_assoc())
{

?>

<tr>

<td><?php echo $row['requestID']; ?></td>

<td>
<img src="images/<?php echo $row['image']; ?>">
</td>

<td><?php echo $row['itemName']; ?></td>

<td><?php echo $row['brand']; ?></td>

<td><?php echo $row['description']; ?></td>

<td>R <?php echo $row['price']; ?></td>

<td><?php echo $row['status']; ?></td>

<td>

<a class="approveBtn"
href="approve.php?approve=<?php echo $row['requestID']; ?>">
Approve
</a>

<a class="deleteBtn"
href="approve.php?delete=<?php echo $row['requestID']; ?>"
onclick="return confirm('Reject this request?')">
Reject
</a>

</td>

</tr>

<?php

}

?>

</table>

</div>

</body>

</html>