<?php
include 'DBConn.php';

if(isset($_POST['send']))
{
    $sender = $_POST['sender'];
    $receiver = $_POST['receiver'];
    $message = $_POST['message'];

    $sql = "INSERT INTO tblMessages(sender,receiver,message)
            VALUES('$sender','$receiver','$message')";

    $conn->query($sql);

    header("Location: messages.php");
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Messages</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="styles.css">

<style>

body{
    background:#f5f5f5;
    font-family:Arial;
}

.container{
    width:80%;
    margin:40px auto;
    background:white;
    padding:30px;
    border-radius:10px;
}

h2{
    text-align:center;
}

input,
select,
textarea{
    width:100%;
    padding:12px;
    margin:10px 0;
}

button{
    background:black;
    color:white;
    padding:12px;
    border:none;
    width:100%;
    cursor:pointer;
}

.message-box{
    border:1px solid #ddd;
    padding:15px;
    margin-top:15px;
    border-radius:8px;
    background:#fafafa;
}

.message-header{
    font-weight:bold;
    margin-bottom:8px;
}

.message-date{
    color:gray;
    font-size:13px;
}

</style>

</head>

<body>

<div class="container">

<h2>Administrator Messages</h2>

<form method="POST">

<label>Sender</label>

<select name="sender" required>

<option value="Administrator">Administrator</option>

<option value="Buyer">Buyer</option>

<option value="Seller">Seller</option>

</select>

<label>Receiver</label>

<select name="receiver" required>

<option value="Buyer">Buyer</option>

<option value="Seller">Seller</option>

<option value="Administrator">Administrator</option>

</select>

<label>Message</label>

<textarea name="message" rows="5" required></textarea>

<button type="submit" name="send">

Send Message

</button>

</form>

<hr>

<h2>Conversation History</h2>

<?php

$result = $conn->query("SELECT * FROM tblMessages ORDER BY dateSent DESC");

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
?>

<div class="message-box">

<div class="message-header">

<?php echo $row['sender']; ?>

→

<?php echo $row['receiver']; ?>

</div>

<div>

<?php echo $row['message']; ?>

</div>

<div class="message-date">

<?php echo $row['dateSent']; ?>

</div>

</div>

<?php

    }
}
else
{
    echo "<p>No messages available.</p>";
}

?>

</div>

</body>

</html>