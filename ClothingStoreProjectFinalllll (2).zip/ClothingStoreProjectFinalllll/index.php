<!DOCTYPE html>
<html>
<head>
    <title>Pastimes Clothing Store</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="styles.css">
</head>

<body>

<div class="center">

    <main class="hero-card" role="main">

        <div class="hero-icons" aria-hidden="true">👗 👕 👖 🧥 👟</div>

        <h1 class="hero-title">Welcome to Pastimes Clothing Store</h1>

        <p class="hero-subtitle">
            Discover trendy outfits, stylish fashion, and modern clothing designed to match your lifestyle.
        </p>

        <div class="button-row">


        <a href="login.php" class="btn" id="loginBtn">
            Login
        </a>

        <a href="register.php" class="btn" id="registerBtn">
            Register
        </a>

        <a href="admin.php" class="btn" id="adminBtn">
            Admin
        </a>

    </div>

    <div class="error" id="error"></div>

        <div class="footer">© 2026 Pastimes Clothing Store</div>

    </main>

</div>

</body>
</html>