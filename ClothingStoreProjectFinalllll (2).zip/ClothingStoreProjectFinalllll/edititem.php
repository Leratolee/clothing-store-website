<?php
include 'DBConn.php';

$id = $_GET['id'];

$result = $conn->query("SELECT * FROM tblClothes WHERE itemID='$id'");

$row = $result->fetch_assoc();

if(isset($_POST['update']))
{

$name = $_POST['itemName'];
$brand = $_POST['brand'];
$price = $_POST['price'];

$conn->query("UPDATE tblClothes
SET itemName='$name',
brand='$brand',
price='$price'
WHERE itemID='$id'");

header("Location: dashboard.php");

}
?>

<!DOCTYPE html>

<html>

<head>

<title>Update Item</title>

<link rel="stylesheet" href="styles.css">

</head>

<body>

<h2>Update Clothing Item</h2>

<form method="POST">

<input type="text" name="itemName"
value="<?php echo $row['itemName']; ?>" required><br><br>

<input type="text" name="brand"
value="<?php echo $row['brand']; ?>" required><br><br>

<input type="number" name="price"
value="<?php echo $row['price']; ?>" required><br><br>

<input type="submit" name="update" value="Update Item">

</form>

</body>

</html>