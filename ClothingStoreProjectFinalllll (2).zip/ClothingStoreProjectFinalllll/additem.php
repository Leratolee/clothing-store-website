<?php
include 'DBConn.php';

if(isset($_POST['add']))
{

$name = $_POST['itemName'];
$price = $_POST['price'];
$brand = $_POST['brand'];

$conn->query("INSERT INTO tblClothes(itemName,price,brand)
VALUES('$name','$price','$brand')");

header("Location: dashboard.php");

}
?>

<!DOCTYPE html>

<html>

<head>

<title>Add Clothing Item</title>

<link rel="stylesheet" href="styles.css">

</head>

<body>

<h2>Add Clothing Item</h2>

<form method="POST">

<input type="text" name="itemName" placeholder="Item Name" required><br><br>

<input type="text" name="brand" placeholder="Brand" required><br><br>

<input type="number" name="price" placeholder="Price" required><br><br>

<input type="submit" name="add" value="Add Item">

</form>

</body>

</html>