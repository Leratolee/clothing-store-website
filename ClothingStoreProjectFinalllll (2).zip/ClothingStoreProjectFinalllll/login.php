<?php
include 'DBConn.php';
session_start();

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = trim($_POST['username']);
    $password = md5(trim($_POST['password']));

    $result = $conn->query("SELECT * FROM tblUser WHERE username='$username'");

    if ($result && $row = $result->fetch_assoc()) {

        if ($row['password'] == $password) {

            if ($row['status'] == "approved") {

                $_SESSION['user'] = $row['name'];

                header("Location: items.php");
                exit();

            } else {
                $message = "⏳ Waiting for admin approval";
            }

        } else {
            $message = "❌ Wrong password";
        }

    } else {
        $message = "❌ User not found";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="styles.css">
</head>

<body>


<div class="center">

  <div class="card form-card">


<h2 class="section-title" style="margin-bottom:16px; font-size:28px;">Login</h2>

<form method="POST">

    <input type="text" name="username" placeholder="Username" required>

    <input type="password" name="password" placeholder="Password" required>


    <button type="submit">Login</button>

</form>

<div class="message error">
    <?php echo $message; ?>
</div>

<a class="btn secondary" href="register.php">Create account</a>



</div>

</body>
</html>

