<?php
include 'DBConn.php';
session_start();

// Check if ID exists
if(isset($_GET['id'])){

    $id = intval($_GET['id']);

    // Secure query
    $stmt = $conn->prepare("UPDATE tblUser SET status='approved' WHERE userID=?");
    $stmt->bind_param("i", $id);

    if($stmt->execute()){
        $message = "Customer account approved successfully!";
    } else {
        $message = "Something went wrong!";
    }

} else {
    $message = "Invalid request!";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Approve Customer</title>

    <meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="styles.css">
</head>

<body>

<main class="center">

  <div class="card form-card">

    <h1 class="section-title" style="margin-bottom:12px; font-size:28px;">Fashion Store Admin</h1>


    <p class="<?php echo ($message == 'Customer account approved successfully!') ? 'success' : 'error'; ?>">
        <?php echo $message; ?>
    </p>

    <a href="dashboard.php" class="btn">Back to Dashboard</a>

  </div>

</main>


</body>
</html>